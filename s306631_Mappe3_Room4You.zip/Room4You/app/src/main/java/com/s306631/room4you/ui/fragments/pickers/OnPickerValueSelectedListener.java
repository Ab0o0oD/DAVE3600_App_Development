package com.s306631.room4you.ui.fragments.pickers;

public interface OnPickerValueSelectedListener {
    void onValueSelected(String data);
}
