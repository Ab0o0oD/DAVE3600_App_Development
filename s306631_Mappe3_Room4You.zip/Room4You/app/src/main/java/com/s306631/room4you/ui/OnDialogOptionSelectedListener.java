package com.s306631.room4you.ui;

public interface OnDialogOptionSelectedListener {
    void onDialogOptionSelected();
}
